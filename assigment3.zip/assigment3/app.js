const path = require('path');
const express = require('express');

const app = express();

const adminRoutes = require('./routes/admin')
const shopRoutes = require('./routes/shop')
// const bodyparser = require('body-parser');

// app.use(bodyparser.urlencoded({extended:false}));
app.use('/admin',adminRoutes);
app.use('/shop',shopRoutes);

app.use ((req,res, next) =>{
    res.status(404).sendFile(path.join(__dirname,'views','404.thml'));
} );



module.exports= app;
