const http = require('http');

 const express = require('express');
 
 const app = express();

  app.use('/',(req, res, next) =>{
      console.log('this is "/"  output');
      res.send('<h1>"/" somethig massage</h1>');
      next();
  });
  app.use('/user',(req, res, next) =>{
    console.log('this is "/user"  output');
    res.send('<h1>"/user" /user massage</h1>');
});
 const  server =  http.createServer(app);

  server.listen(3000);

